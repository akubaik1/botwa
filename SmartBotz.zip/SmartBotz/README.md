
## CARA INSTALL
```bash
> termux-setup-storage [Y]
> cd /sdcard
> cd -r Alphabot /$HOME
> cd Alphabot
> bash install.sh 
> npm start
> Now scan the QR
```
